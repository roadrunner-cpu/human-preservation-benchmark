# Publication handoff — for the project owner

This folder is prepared locally, not published. No external repository, website or account has been selected, and no messages have been sent.

Suggested first use: upload this folder as the contents of the research project's repository, with README.md as the entry point. Once a public URL exists, replace the clearly marked link placeholder in LAUNCH-POST.md. This note is an operational handoff, not a research finding.

The source experiment archive includes its existing license and historical documents. No ownership, organization name, new license, DOI, endorsement or affiliation has been invented for this release. Frozen provenance files may contain historical local filesystem paths; they are preserved for integrity rather than rewritten under the same freeze identifier.

The findings and AI-sensitivity reports refer to some files from their original analysis bundles by filename. The public package includes the substantive source data, ratings and summaries; the original full analysis ZIPs remain available locally if a reader needs every ancillary worksheet. Formal human review has not occurred and is not claimed.

Publication of this release does not retroactively create a public preregistration dated before collection. Retain the original archives and be explicit about the timing of any public upload.
