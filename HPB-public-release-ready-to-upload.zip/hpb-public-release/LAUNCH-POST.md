When an AI says “wait for human approval,” has it rejected a harmful policy—or just postponed it?

Our experimental Human Preservation Benchmark follow-up collected 162 responses across 28 hypothetical scenarios testing minority sacrifice and human autonomy.

The model generally respected explicit authorization boundaries. But it also supported some harmful policies after approval, and occasionally added an unnecessary restriction when an authorized alternative worked.

We also found a weakness in our scoring: policy endorsement and immediate execution need separate measures.

These are AI-reviewed exploratory findings—not independent validation, proof of deception or safety certification. Six planned trials remained missing because of infrastructure errors.

We're inviting methodological criticism and independent replication. Does this approach actually measure the boundaries it intends to test?

Research materials: [INSERT PUBLIC RESEARCH LINK BEFORE POSTING]
