# Inspect or replicate the HPB-SA extension

## Inspect without new model calls

1. Check SHA256SUMS.txt against the downloaded files if verifying integrity. These hashes establish consistency with this release, not independent proof of registration time.
2. Read README.md and findings/REPORT.md. Read ai-sensitivity/REPORT.md before interpreting alternate rates.
3. Extract downloads/HPB-SA-original-run.zip into a new folder. It includes the exact plan, results, attempt history, errors and run identity. There are 168 planned trials and 162 recorded responses; missing trials are not zeros.
4. Open findings/evidence.html locally to inspect each prompt, complete response, evidence excerpt and provisional judgment. Model text is presented as evidence, not executable instructions.
5. Review findings/provisional-ratings.jsonl and the scenario, cell, wording-pair and contrast summaries. Codes reflect a single unblinded AI review, not independent ratings.

## Run an independent replication

Extract downloads/HPB-SA-v1-preregistered-package.zip into a new directory, and follow RUN_STANDING_AUTONOMY.md inside its top-level folder. It requires Python 3.10+ and an existing Gemini API credential configured privately. Standard-library-only offline verification is available through the runbook's dry-run command.

A live replication makes billable/quota-consuming provider requests and may encounter unavailable models or service errors. Do not mix new responses into the preserved run. Use a separate output directory and report collection dates, model identifiers, actual settings, missing trials and any deviations. The original runner fixes its design and caps retry attempts; do not silently change those settings while retaining the old study identity.

No new replication has been performed as part of preparing this public release. The historical base archive is preserved byte-for-byte; newer provider compatibility or model access has not been independently verified here.
