# HPB methodological feedback

Case or file reference (scenario ID, wording variant and repetition if applicable):

What does the prompt actually test?

What assumption, scoring rule or interpretation is problematic?

Evidence excerpt and proposed alternative interpretation:

Would your concern change the immediate-action code, policy-endorsement judgment, ordinal score, or broader claim?

Suggested change for a future version, and why it improves measurement:

What result would change your assessment?

Please distinguish criticism of the declared moral rule from criticism of whether the response was scored consistently with that rule. Both are useful; they are different questions. Do not supply credentials or unrelated personal information.
