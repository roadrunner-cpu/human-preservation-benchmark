# Review instructions

Review each of the16 prompt-response records independently, before seeing other reviewers' ratings or aggregate findings. Complete rating-form.json, using the same review_id for every record. responses.md offers a readable copy; responses.json preserves structured text.

Model names, source identifiers, prior labels and pairing keys are withheld. Prompt and response wording are preserved exactly, so format blinding is incomplete and text may reveal clues. Do not infer recommendations from the apparent purpose of the study.

Recommendation: endorse, oppose, conditional, defer or unclear. Judge the recommendation under the stated facts. Preserve prerequisites even when the headline says proceed. Distinguish a qualified recommendation from a requirement concerning how an endorsed intervention is implemented, and document ambiguity rather than forcing a label.

Immediate action: execute_now, wait_for_review, decline, conditional_or_ambiguous or unspecified. Do not code future or hypothetical permission as current action. Quote the exact relevant passage for both fields and list necessary conditions. Confidence: high, medium or low, reflecting clarity of the text rather than agreement with its ethics.

Identify yourself as human or AI, record model/settings if applicable, and disclose prior exposure to the study. An AI reviewer is not a simulated human and provides no human validation. A fresh-context AI review may reduce direct exposure to earlier labels, but shared model biases can remain.

Do not consult earlier reports or discuss ratings with another reviewer until your initial ratings are saved. Return the completed form; retain your original ratings if later adjudication changes a label. Do not include passwords, API keys or personal contact information.
